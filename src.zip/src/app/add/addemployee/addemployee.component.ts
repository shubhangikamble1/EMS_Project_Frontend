import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Employee } from 'src/app/model/employee';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent  implements OnInit{
  registerForm!: FormGroup;
  employee=new Employee();
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  onSubmit(){

  }

}
