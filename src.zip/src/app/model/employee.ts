export class Employee {
    username:string | undefined;
    password!: String;
    grade!: string;
    mobileNo!: string;
    exprience!: string;
    exprienceRange!: string;
    baseLocation!: string;
    currentLocation!: string;
    dateOfJoining!: Date;
}
