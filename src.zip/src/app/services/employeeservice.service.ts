import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from '../model/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeserviceService {

  constructor(private http:HttpClient) { }

  fetchEmployeeDetailsByRemote(employee:Employee){
    this.http.get("");
  }
  addEmployeeDetailsByRemote(){
    
  }
}
