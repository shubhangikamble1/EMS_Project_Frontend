import { Component } from '@angular/core';

@Component({
  selector: 'app-evaluationlist',
  templateUrl: './evaluationlist.component.html',
  styleUrls: ['./evaluationlist.component.css']
})
export class EvaluationlistComponent {

}
