import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ratingdescription',
  templateUrl: './ratingdescription.component.html',
  styleUrls: ['./ratingdescription.component.css']
})
export class RatingdescriptionComponent  implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
