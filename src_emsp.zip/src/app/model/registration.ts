export class Registration {
    username:string;
	 email:string;
	 password:string;
	confirmPassword:string;

}
